# C11312 配置RAM回读校验辅助包

本包仅含原C11312的 `spectrum_trace.bmk` 掩码、来源校验证明和本说明，**没有新bit，不是修复版**。

## 实验室操作

1. 解压，将 `spectrum_trace.bmk` 放到已核对的 `E:\anlu\bit\spectrum_trace.bit` 同目录，文件名基名保持一致。原bit保持原样。
2. 板卡和AL-LINK接法保持已验证状态。校验对象必须是板内当前加载的C11312；如果已回载基线，不能直接拿C11312校验它，须先按原成功方式加载这份C11312一次。加载后到校验结束期间不掉电、不替换位流。
3. 在BitWriter中选择器件EG4S20BG256和这份 `spectrum_trace.bit`，保持5MHz，将Mode/Operation改为 **Verify SRAM（VERIFY_SRAM）**，执行一次。若出现掩码选择框，选同目录的 `spectrum_trace.bmk`。
4. 把本次完整日志发回。若下拉框没有Verify SRAM，或提示不支持/找不到mask/无mask，发模式列表和错误；不要以普通Download成功代替本次校验结果。

本轮要比较芯片当前配置与原始位流，使用Verify SRAM操作；不涉及Flash固化。需要记录软件是否载入掩码和具体比较结果。单纯出现失配，尚不能直接断言芯片/下载器损坏，需先核对板内版本和动态位掩码是否正确应用。

## 文件来源与已验证范围

- 原bit：634280字节，SHA256 `60AE6B971CE1F9ED09D76BEC14CF88DFC25CDFE7CBBEBE5DD9FC070115B812CE`；实验室已由用户脚本截图确认一致。
- 掩码来自原C11312最终routed DB，DB与10月15日冻结manifest SHA相符。只执行bitgen -gen_mask到隔离目录，未重新综合/布局布线或修改源代码、约束和原交付bit。
- 隔离生成的参考bit与原交付bit除Date注释4字节外完全一致，配置内容逐字节相同。参考bit仅用于来源核对，没有装入本包。
- TD 6.2.178840已为EG4S20BG256生成bmk。原厂SWUG110第4.3.2说明Verify SRAM回读配置RAM，不包含用户ERAM；第4.3.10为Read Save SRAM，二者不同。
- **尚未实板Verify SRAM。** 本机离线bit_to_vec jtag_rdbk转换能运行，但测试转换日志仍为0 bits masked，不能作为正确应用本bmk的校验通过证据，也未把这些未验证向量发给用户。下一步由GUI Verify SRAM实际接收掩码及比较日志确认。

## 结果意义

校验通过仅表明本操作实际覆盖的配置位一致，不代表PLL物理时钟、复位时序、用户ERAM/FFT内容或音画功能正常。校验失败需要先审阅完整日志、掩码应用与失配位置。本轮根因仍未确定。
