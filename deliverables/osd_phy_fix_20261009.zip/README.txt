OSD串行采样修复候选（2026-10-09）

这是待上板验证的新候选，已完成模型、编译及原约束时序检查。
旧OSD首版实板花屏/静音，同条件回载packet_diag已恢复。

保持现有TF卡、供电、HDMI和音量，卡内四图和TEST.WAV无需修改。
解压到英文路径；在BitWriter选择PROGRAM_SRAM，添加
firmware/osd_phy_fix.bit，下载后等待 Downloading succeeded!。
本机短路径：E:/VSCODE-project/FPGA-ANLU/download/osd_phy_fix.bit。

验证：
1. 四张图颜色正常，无密集噪点、条纹或黑块；左上状态栏黑底白字。
2. 默认天之弱音乐正常；运行两次60秒循环。
3. KEY0短按切图且IMG编号一致；KEY1短按切MANUAL/AUTO并自动轮播。
4. KEY1长按约2秒切内部音阶，D3闪烁，音阶清楚且图像正常。
   长按也会切换一次轮播状态。松开至少1.5秒后再次长按可回WAV。

如果图像或声音仍异常，保存现象并回载firmware/packet_diag.bit。
旧osd.bit不是修正版。当前只临时写FPGA SRAM，掉电会重载Flash原例程。

本次修改仅在每个HDMI串行器中提前一个125MHz周期暂存10位数据字；
移位/ODDR发送时刻保持原样。图片、音频文件通路、OSD、PLL、引脚、
时序约束源码不变；物理实现优化及最终数值见build_info.json。
延迟模型可复现混字并由候选消除；真实板上的具体原因尚未实测证实。
